import type { Locale } from '@nagarikwatch/db'
import { getRealWeather, getRealAqi, getRealNepse } from '@/lib/live/real'
import { aqiBand, localizeNumber, relativeTime } from '@/lib/live/format'

export async function UtilityStrip({ locale }: { locale: Locale }) {
  const lang = locale === 'en' ? 'en' : 'ne'
  const [weather, aqi, nepse] = await Promise.all([
    getRealWeather(locale),
    getRealAqi(locale),
    getRealNepse(locale),
  ])

  const items: Array<{
    label: string
    value: string
    note?: string
    href?: string
    tone?: string
  }> = []
  if (weather.status === 'ok' && weather.data) {
    items.push({
      label: locale === 'en' ? weather.data.placeEn : weather.data.placeNe,
      value: `${localizeNumber(weather.data.tempC, locale)}°C`,
      note: weather.source,
    })
  }
  if (aqi.status === 'ok' && aqi.data) {
    const band = aqiBand(aqi.data.aqi, locale)
    items.push({ label: 'AQI', value: localizeNumber(aqi.data.aqi, locale), note: band.label })
  }
  if (nepse.status === 'ok' && nepse.data) {
    const up = nepse.data.changePercent >= 0
    items.push({
      label: 'NEPSE',
      value: localizeNumber(nepse.data.index.toFixed(2), locale),
      note: `${up ? '▲' : '▼'} ${localizeNumber(Math.abs(nepse.data.changePercent).toFixed(2), locale)}%`,
      href: `${locale === 'en' ? '/en' : ''}/market`,
      tone: up ? 'text-up' : 'text-down',
    })
  }

  if (items.length === 0) return null

  const updated = relativeTime(nepse.updatedAt, locale)

  return (
    <div
      className="hidden border-b border-rule bg-surface-raised/70 lg:block"
      role="complementary"
      aria-label={locale === 'en' ? 'Daily reference line' : 'दैनिक सन्दर्भ लाइन'}
    >
      <div className="mx-auto flex max-w-page items-center gap-5 overflow-x-auto px-4 py-2 text-caption text-ink-soft [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <span
          className="shrink-0 font-bold uppercase tracking-[0.16em] text-brand-strong"
          lang={lang}
        >
          {locale === 'en' ? 'Reference' : 'सन्दर्भ'}
        </span>
        {items.map((item) => {
          const inner = (
            <>
              <span
                className="font-semibold uppercase tracking-wide text-mute"
                lang={item.label === 'NEPSE' || item.label === 'AQI' ? 'en' : lang}
              >
                {item.label}
              </span>
              <span className="font-semibold text-ink">{item.value}</span>
              {item.note ? <span className={item.tone ?? 'text-mute'}>{item.note}</span> : null}
            </>
          )
          return item.href ? (
            <a
              key={item.label}
              href={item.href}
              className="inline-flex shrink-0 items-center gap-2 hover:text-brand-strong"
            >
              {inner}
            </a>
          ) : (
            <span key={item.label} className="inline-flex shrink-0 items-center gap-2">
              {inner}
            </span>
          )
        })}
        {updated ? (
          <span className="ml-auto shrink-0 text-mute" lang={lang}>
            {updated}
          </span>
        ) : null}
      </div>
    </div>
  )
}
